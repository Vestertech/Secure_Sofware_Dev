<?PHP
$authenticated = False;
$auth_fail = False;
$create_fail = True;
$session = isset($_COOKIE['session'])?$_COOKIE['session']:False;
$username = isset($_POST['username'])?$_POST['username']:False;
$password = isset($_POST['password'])?$_POST['password']:False;
$function = isset($_POST['function'])?$_POST['function']:False;
$dsn = 'mysql:dbname=ontario_computers;host=localhost'; 
$dbUser = 'appuser';
$dbPassword = 'Testing!'; 
$db = new PDO($dsn,$dbUser,$dbPassword); 
if ( $function === 'Create Account' and $username !== False and $password !== False ) {
	$query =  sprintf("SELECT count(*) FROM authentication WHERE username = '%s';",$username);
	$cursor = $db->query($query);
	$count = $cursor->fetchColumn();
	if ( $count == 0 ) {
		$sql = sprintf("INSERT INTO authentication (username,password) VALUES ('%s',md5('%s'));",$username,$password);
		$db->exec($sql);
		$create_fail = False;
	} 
} else { 
if ( $username !== False and $password !== False ) { 
	$query = sprintf ("SELECT count(*) from authentication WHERE username = '%s' AND password = md5('%s');",$username,$password);
	$cursor = $db->query($query);
	$count = $cursor->fetchColumn();
	if ( $count > 0 ) {
		$session_id = (string) rand(1,1000);
		$sql = sprintf("INSERT INTO sessions (username,session_id) VALUES ('%s',md5('%s'));",$username,$session_id);
		$db->exec($sql);
		setcookie('session',$session_id);
		$authenticated = True;
	} else {
		$auth_fail = True;
	}
} elseif ( $session !== False ) {
	$session_exists = False;
	$query = sprintf ("SELECT username from sessions where session_id = md5('%s') order by issue_date;",$_COOKIE['session']);
	$cursor = $db->query($query);
	$fetchedName = $cursor->fetchObject();
	if ($fetchedName->username == Null ) {
		$auth_fail = True;
	} else {
		$username = $fetchedName->username;	
		$authenticated = True;
	}
}
}
?>
<HTML>
<HEAD><style> table { border-collapse: collapse; width: 100%; }
th, td { text-align: left; padding: 8px; }
tr:nth-child(even)
{ background-color: Lightgreen; }</style>
</HEAD>
<BODY><h1 style='text-align:center'>Welcome to Caribou Computers</h1>
<div style="height:100px;border:2px solid black;text-align:center;position:relative;">
<?PHP
if ( !$authenticated ) {
?>
<form method="POST">
<div style='margin-top:10px;'>Username: <input type="text" name="username">
Password: <input type="password" name="password">
<input type="submit" name='function' value="Login"><input type="submit" name="function" value="Create Account" />
</div></form>
<?PHP
if ( !$create_fail ) { printf("<span style='color:green;'>Account %s created!</span>",$username); }
elseif ( $auth_fail ) { printf("<span style='color:red;'>Authentication failed</span>"); }
} else {
?>
<span style='color:green;'>Logged in as:<?=$username?>!</span>
<?PHP
$ref = isset($_GET['referrer'])?$_GET['referrer']:False;
if ($ref !== False) { printf ("<br/>Referred by: %s",$ref);}
?>
</div><table><tr><th>Item #</th><th>Name</th><th>Description</th><th>Price</th></tr>
<?PHP
$search = isset($_GET['search'])?" WHERE item_name LIKE ('%".$_GET['search']."%')":"";
$query_string = "SELECT * FROM items".$search;
$cursor = $db->query($query_string);
while ( $data = $cursor->fetchObject() ) {
	printf("<tr><td>%d</td><td>%s</td><td>%s</td><td>%.2f</td></tr>",$data->item_id,$data->item_name,$data->item_description,$data->price);
	
	}  
?></table>
<?PHP } ?>
</BODY></HTML>