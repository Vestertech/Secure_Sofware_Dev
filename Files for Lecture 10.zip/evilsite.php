<?PHP
$dsn = 'mysql:dbname=evilsite_comments;host=localhost';
$dbUser = 'appuser';
$password = 'Testing!';
$db = new PDO($dsn,$dbUser,$password);

$comment = isset($_GET['comment'])?$_GET['comment']:False;
$query =  sprintf("INSERT INTO comments (comment_text) values ('%s');",$_GET['comment']);
if ($comment !== False) {$db->exec($query);}
?>
<style> table { table-layout:fixed;border-collapse: collapse; width: 100%; }
th, td { text-align: left; padding: 8px; }
tr:nth-child(even)
{ background-color: Lightblue; }
.short {width:12%;}</style>
</HEAD>
<body>
<h1>There is nothing suspicious about this site!</h1>
<table><colgroup><col class='short'/><col/></colgroup><tr><th>Comment #</th><th>Message</th></tr>
<?PHP
$query_string = "SELECT * FROM comments;";
$cursor = $db->query($query_string);
while ( $data = $cursor->fetchObject() ) {
	printf("<tr><td>%d</td><td>%s</td></tr>",$data->comment_id,$data->comment_text);
	
	}  
?></table></BODY>

Help support my site.  Use this link for shopping
<a href="caribou_computers.php">Go to Caribou Computers</a>
<h2>Sign my guestbook</h2>
<form><input type="text" name="comment"><input type="submit" value="Submit Comment!"></form>