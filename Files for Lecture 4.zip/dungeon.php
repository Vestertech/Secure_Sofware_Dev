<HTML><BODY><H1>The Very Short Dungeon!</H1>
<p>Welcome Adventurer!</p>
<?PHP
error_reporting(E_ALL);
$room_number = 0;
$player_accuracy = 55;
$player_damage = 8;
$player_health = 100;
$monsters = array("A Balrog","An Orc","A Troll","An Evil Wizard");
$monster_health = array(100,20,50,5);
$monster_weapon = array("a Flaming Whip","an Axe","sharp claws","a Fireball spell");
$monster_damage = array(8,2,4,10);
$monster_accuracy = array(40,60,50,80);
while ($player_health > 0 ) {
	printf ("<p>You enter room #%d</p>",++$room_number);
	$room_contents = rand(0,4);
	if ($room_contents == 4) { 
    	printf("<p>Strange.  It appears to be empty</p>");
        continue;
    }
	else {
		printf ("<h4>%s with %s is in this room.</h4><p>",$monsters[$room_contents],$monster_weapon[$room_contents]);
    	$m_health = $monster_health[$room_contents];
    	while ( $m_health > 0 and $player_health > 0 ) {
        	$attack_roll = rand(1,100);
			$damage_roll = rand(1,$player_damage);
			$monster_roll = rand(1,100);
			$m_damage = rand(1,$monster_damage[$room_contents]);
			if ($attack_roll < $player_accuracy) {
				$m_health -= $damage_roll;
				printf ("You attack and hit for %d points!<br>",$damage_roll);
				if ( $m_health < 1 ) { printf("You killed it!<br>"); $player_accuracy+5; break; }
            } else {
            	printf ("You attack and miss!<br>");
            }
        	if ( $monster_roll < $monster_accuracy[$room_contents]) {
            	$player_health -= $m_damage;
            	printf ("%s attacks and hits you with %s for %d points!<br>",$monsters[$room_contents],$monster_weapon[$room_contents],$m_damage);
            }
        	else {
            	printf ("%s attacks and misses<br>",$monsters[$room_contents]);
            }
        }
		}
	}
printf("<p>You have died after exploring %d rooms.</p>",$room_number);
?>
</BODY></HTML>