<html><head>
<style> table { table-layout:fixed;border-collapse: collapse; width: 100%; }
th, td { text-align: left; padding: 8px; }
tr:nth-child(even)
{ background-color: Lightblue; }
.short {width:12%;}</style>
</head><body>
<?PHP
$authenticated = False;
$session = isset($_COOKIE['session'])?$_COOKIE['session']:False;
$newpass = isset($_GET['newpass'])?$_GET['newpass']:False;
$changepass = False;
if ( $newpass !== False ) {
	foreach ( $_GET as $name_for_passchange => $changepass) {
    	if ( $changepass = 'on' ) { break; }
    }
}
$dsn = 'mysql:dbname=ontario_computers;host=localhost'; 
$dbUser = 'appuser';
$dbPassword = 'Testing!'; 
$db = new PDO($dsn,$dbUser,$dbPassword); 
if ( $session !== False ) {
	$session_exists = False;
	$query = sprintf ("SELECT username from sessions where username = 'administrator' and session_id = md5('%s') order by issue_date;",$_COOKIE['session']);
	$cursor = $db->query($query);
	$fetchedName = $cursor->fetchObject();
	if ($fetchedName->username == Null ) {
		$auth_fail = True;
	} else {
		$username = $fetchedName->username;	
		$authenticated = True;
	}
}
if ( $authenticated === True ) {
?>
<h1>Administrative Page</h1>
<?PHP
if ( $changepass !== False ) {
$query =  sprintf("update authentication set password = md5('%s') where username = '%s'",$newpass,$name_for_passchange);
$db->exec($query);
printf("<span style='color:green;'>Password for %s changed!</span>",$name_for_passchange);
}
?>
<form>
<table><colgroup><col class='short'/><col/></colgroup><tr><th>Select</th><th>Username</th></tr>
<?PHP
$query_string = "SELECT username FROM authentication;";
$cursor = $db->query($query_string);
while ( $data = $cursor->fetchObject() ) {
	printf("<tr><td><input type='radio' name='%s' /></td><td>%s</td></tr>",$data->username,$data->username); }
?></table>
<input type="text" name='newpass'><input type='submit' value='Change Password'>
</form>
<?PHP
} else {
?>
<h1 style='text-align:center'>Go Away</h1>
<?PHP
}
?>
</body></html>