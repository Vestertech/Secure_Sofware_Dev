-- Adminer 4.7.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP DATABASE IF EXISTS `ontario_computers`;
CREATE DATABASE `ontario_computers` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `ontario_computers`;

DROP TABLE IF EXISTS `authentication`;
CREATE TABLE `authentication` (
  `username` varchar(20) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `authentication` (`username`, `password`) VALUES
('administrator',	'8b98d3ce4e5dba2d7677fba05e87c2a0'),
('stockboy',	'fa2dd5c3ac46e376aeae191fd9788458');

DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_text` longtext NOT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4;

INSERT INTO `comments` (`comment_id`, `comment_text`) VALUES
(1,	'Nice comment page!'),
(2,	'Can anyone recommend RAM for a Lenovo W530?');

DROP TABLE IF EXISTS `items`;
CREATE TABLE `items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(40) NOT NULL,
  `item_description` varchar(255) NOT NULL,
  `price` float NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `items` (`item_id`, `item_name`, `item_description`, `price`) VALUES
(1,	'CORSAIR DDR4-2400 32GB SODIMM KIT',	'2x16 GB SODIMMS c16',	190),
(2,	'Western Digital 4TB PURPLE - WD40PURZ ',	'Surveillance Internal Hard Drive - 5400 RPM Class, SATA 6 Gb/s, , 64 MB Cache, 3.5\" - ',	100);

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `username` varchar(20) NOT NULL,
  `session_id` varchar(40) NOT NULL,
  `issue_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `sessions` (`username`, `session_id`, `issue_date`) VALUES
('administrator',	'2f29b6e3abc6ebdefb55456ea6ca5dc8',	'2021-01-26 07:44:03');

-- 2021-02-05 02:42:01
