<?PHP
if (isset($_POST['name']) ){	sleep(rand(1,3));	$id = session_create_id();	print $id; }
	else { 
		print "GET request. No body data sent.";
		}?>

