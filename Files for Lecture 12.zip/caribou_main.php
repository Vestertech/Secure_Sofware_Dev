<?PHP
printf("<table><tr><th>Item #</th><th>Name</th><th>Description</th><th>Price</th></tr>");
$search = isset($_GET['search'])?" WHERE item_name LIKE ('%".$_GET['search']."%')":"";
$query_string = "SELECT * FROM items".$search;
$cursor = $db->query($query_string);
while ( $data = $cursor->fetchObject() ) {
	printf("<tr><td>%d</td><td>%s</td><td>%s</td><td>%.2f</td></tr>",$data->item_id,$data->item_name,$data->item_description,$data->price);
	
	}  
printf("</table><table><colgroup><col class='short'/><col/></colgroup><tr><th>Comment #</th><th>Message</th></tr>");
printf("<hr />");
$query_string = "SELECT * FROM comments;";
$cursor = $db->query($query_string);
while ( $data = $cursor->fetchObject() ) {
	printf("<tr><td>%d</td><td>%s</td></tr>",$data->comment_id,$data->comment_text);
	
	}  
printf("</table><div><form method='POST'><textarea name='comment' style='width:900px;'></textarea><input type='submit' value='Post Comment' />");
printf("</BODY></HTML>");
?>