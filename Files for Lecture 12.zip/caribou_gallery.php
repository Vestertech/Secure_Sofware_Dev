<h1>Share images of your rig!</h1>
<?PHP
if ($authenticated === True) {
$scan_dir = scandir('./test');
foreach ($scan_dir as $file) {
	if ( substr($file,-4) === '.jpg') 
    {
    printf("<img style='width:100px;height:100px' src='./test/%s' />",$file);
    } 
}
?>
<form  method="post" enctype="multipart/form-data">
  Select image to upload:
  <input type="file" name="fileToUpload" id="fileToUpload">
  <input type="submit" value="Upload Image" name="submit">
</form>
</body>
</html>
<?php
$target_dir = "test/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
if(isset($_POST["submit"])) {
move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], "$target_file");
printf("<script>window.location = '/includer.php?page=caribou_gallery.php'</script>");
}}?>