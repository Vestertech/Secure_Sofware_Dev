<?php
printf ("Contents of the ./test directory<br><br>");
$input = $_GET["filter"];

exec("ls ./test/".$input,$output);
foreach ($output as $line) {
     printf("%s<br>",$line);
}

?>