<?php
isset($_GET['calcthis'])?$calc=$_GET['calcthis']:$calc="0";
$secretPassword = 'larryiscool!#';
$username = 'xiaoli';
?><html> 
   <head> 
      <style> 
      	 td{
         background-color: tan;
      }
         input[type="button"] 
         { 
         background-color:SaddleBrown; 
         color:white; 
         border: solid black 1.5px; 
         width:100% 
         } 
  
         input[type="text"] 
         { 
         background-color:khaki; 
         color: black'
         border: solid black 1.5px; 
         width:100% 
         } 
      </style> 
   </head> 
   <!-- create table -->
   <body> 
      <form name="form1" id='myform' action="calc.php">
	  <table border="1"> 
         <tr> 
            <td colspan="3"><input type="text" name="calcthis" id="result" value="<?PHP eval('echo '.$calc.';')?>"/></td> 
            <!-- clr() function will call clr to clear all value -->
            <td><input type="button" value="c" onclick="form['result'].value=''"/> </td> 
         </tr> 
         <tr> 
            <td><input type="button" value="1" onclick="form['result'].value+='1'"/> </td> 
            <td><input type="button" value="2" onclick="form['result'].value+='2'"/> </td> 
            <td><input type="button" value="3" onclick="form['result'].value+='3'"/> </td> 
            <td><input type="button" value="/" onclick="form['result'].value+='/'"/> </td> 
         </tr> 
         <tr> 
            <td><input type="button" value="4" onclick="form['result'].value+='4'"/> </td> 
            <td><input type="button" value="5" onclick="form['result'].value+='5'"/> </td> 
            <td><input type="button" value="6" onclick="form['result'].value+='6'"/> </td> 
            <td><input type="button" value="-" onclick="form['result'].value+='-'"/> </td> 
         </tr> 
         <tr> 
            <td><input type="button" value="7" onclick="form['result'].value+='7'"/> </td> 
            <td><input type="button" value="8" onclick="form['result'].value+='8'"/> </td> 
            <td><input type="button" value="9" onclick="form['result'].value+='9'"/> </td> 
            <td><input type="button" value="+" onclick="form['result'].value+='+'"/> </td> 
         </tr> 
         <tr> 
            <td><input type="button" value="." onclick="form['result'].value+='.'"/> </td> 
            <td><input type="button" value="0" onclick="form['result'].value+='0'"/> </td> 
            <td><input type="submit" value="=" form="myform"/> </td> 
            <td><input type="button" value="*" onclick="form['result'].value+='*'"/> </td> 
         </tr> 
      </table>
	</form>
   </body> 
</html> 
