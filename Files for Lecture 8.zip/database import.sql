-- Adminer 4.7.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

CREATE DATABASE `ontario_computers` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `ontario_computers`;

DROP TABLE IF EXISTS `authentication`;
CREATE TABLE `authentication` (
  `username` varchar(20) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `authentication` (`username`, `password`) VALUES
('administrator',	'8b98d3ce4e5dba2d7677fba05e87c2a0'),
('stockboy',	'fa2dd5c3ac46e376aeae191fd9788458');

DROP TABLE IF EXISTS `items`;
CREATE TABLE `items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(40) NOT NULL,
  `item_description` varchar(255) NOT NULL,
  `price` float NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `items` (`item_id`, `item_name`, `item_description`, `price`) VALUES
(1,	'CORSAIR DDR4-2400 32GB SODIMM KIT',	'2x16 GB SODIMMS c16',	190),
(2,	'Western Digital 4TB PURPLE - WD40PURZ ',	'Surveillance Internal Hard Drive - 5400 RPM Class, SATA 6 Gb/s, , 64 MB Cache, 3.5\" - ',	100);

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `username` varchar(20) NOT NULL,
  `session_id` varchar(40) NOT NULL,
  `issue_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `sessions` (`username`, `session_id`, `issue_date`) VALUES
('administrator',	'2f29b6e3abc6ebdefb55456ea6ca5dc8',	'2021-01-26 07:44:03'),
('administrator',	'459a4ddcb586f24efd9395aa7662bc7c',	'2021-01-26 07:52:27'),
('administrator',	'839ab46820b524afda05122893c2fe8e',	'2021-01-26 17:45:00');

CREATE USER 'appuser'@'localhost' IDENTIFIED BY 'Testing!';
GRANT ALL PRIVILEGES ON * . * TO 'appuser'@'localhost';
-- 2021-01-27 01:25:59
